package com.seuusuario.camerartsp

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.android.exoplayer2.ExoPlayer
import com.google.android.exoplayer2.MediaItem
import com.google.android.exoplayer2.source.rtsp.RtspMediaSource
import com.google.android.exoplayer2.ui.StyledPlayerView

class MainActivity : AppCompatActivity() {

    // Configurar URL RTSP da Câmera
    private val rtspUrl = "rtsp://admin:senha@192.168.1.100:554/stream1"
    private var player: ExoPlayer? = null
    private lateinit var playerView: StyledPlayerView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        playerView = findViewById(R.id.playerView)

        // Registrar o canal da Câmera na Home do Android TV
        TvChannelHelper.criarCanalCameraNaHome(this)

        // Tentar abrir no VLC se instalado, caso contrário usar ExoPlayer Nativo
        if (isPackageInstalled("org.videolan.vlc")) {
            abrirNoVLC(rtspUrl)
        } else {
            iniciarExoPlayer(rtspUrl)
        }
    }

    private fun abrirNoVLC(url: String) {
        val vlcIntent = Intent(Intent.ACTION_VIEW).apply {
            setPackage("org.videolan.vlc")
            setDataAndType(Uri.parse(url), "video/*")
            putExtra("title", "Câmera ao Vivo")
            putExtra("from_start", true)
            putExtra("network-caching", 150) // Reduz buffer para baixa latência
        }
        try {
            startActivity(vlcIntent)
            finish()
        } catch (e: Exception) {
            iniciarExoPlayer(url)
        }
    }

    private fun iniciarExoPlayer(url: String) {
        try {
            player = ExoPlayer.Builder(this).build()
            playerView.player = player

            val mediaItem = MediaItem.fromUri(url)
            val mediaSource = RtspMediaSource.Factory()
                .setForceUseRtpTcp(true) // Melhora estabilidade em rede local
                .createMediaSource(mediaItem)

            player?.setMediaSource(mediaSource)
            player?.prepare()
            player?.playWhenReady = true
        } catch (e: Exception) {
            Toast.makeText(this, "Erro ao carregar RTSP nativo: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun isPackageInstalled(packageName: String): Boolean {
        return try {
            packageManager.getPackageInfo(packageName, 0)
            true
        } catch (e: Exception) {
            false
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        player?.release()
        player = null
    }
}
