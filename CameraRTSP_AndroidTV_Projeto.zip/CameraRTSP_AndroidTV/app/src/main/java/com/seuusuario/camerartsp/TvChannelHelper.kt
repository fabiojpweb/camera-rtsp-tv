package com.seuusuario.camerartsp

import android.content.Context
import android.net.Uri
import androidx.tvprovider.media.tv.Channel
import androidx.tvprovider.media.tv.PreviewProgram
import androidx.tvprovider.media.tv.TvContractCompat

object TvChannelHelper {

    fun criarCanalCameraNaHome(context: Context) {
        try {
            val builder = Channel.Builder()
                .setType(TvContractCompat.Channels.TYPE_PREVIEW)
                .setDisplayName("Segurança Residencial")
                .setAppData(Uri.parse("rtsp_app://channel"))

            val channelUri = context.contentResolver.insert(
                TvContractCompat.Channels.CONTENT_URI,
                builder.build().toContentValues()
            )

            val channelId = channelUri?.lastPathSegment?.toLong() ?: return

            val program = PreviewProgram.Builder()
                .setChannelId(channelId)
                .setTitle("Câmera Principal - Ao Vivo")
                .setDescription("Clique para assistir em tela cheia")
                .setType(TvContractCompat.PreviewPrograms.TYPE_CLIP)
                .setIntentUri(Uri.parse("rtsp_app://open_camera"))
                .build()

            context.contentResolver.insert(
                TvContractCompat.PreviewPrograms.CONTENT_URI,
                program.toContentValues()
            )
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }
}
